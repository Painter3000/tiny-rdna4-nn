# Phase 4A3-Q0d long4x evidence freeze

## Identität

- Run-ID: `phase4a3_q0d_long4x_20260728T091915Z`
- Q0c-Freeze-Commit: `47331167a366223c01d9b27c0ce1d4d2db1ab05b`
- Profil: `long4x`
- Schedule: `spin`
- Auto-Sensitivität: nicht enthalten
- Worker: 16 frische Prozesse

## Ergebnis

- LN, Batch 256: 1/4 gültige Prozesse – BLOCKED
- LP, Batch 1: 4/4 gültige Prozesse – PASS
- LP, Batch 31: 4/4 gültige Prozesse – PASS
- LP, Batch 128: 4/4 gültige Prozesse – PASS

Gesamtstatus:

```text
PHASE4A3_Q0D_LATENCY_PROFILE_BLOCKED
spin_profile_qualified=false
performance_claim_allowed=false
```

Q0d qualifiziert ausschließlich die LN-/LP-Messapparatur. Es trifft keine
Performanceentscheidung und erlaubt keinen Speedup- oder Gesamtclaim.

## Inhalt

- `matrix.tsv`
- `phase4a3_q0d_result.json`
- `run_summary.txt`
- `worker_manifest.json`
- `workers/`: 16 JSON-, 16 Log- und 16 PID-Dateien
- `SHA256SUMS`: originale Hashliste des Q0d-Runners
- `SHA256SUMS_BUNDLE`: Hashliste aller Dateien dieses Freeze-Bundles
- `coredumps/`: ursprüngliches Coredump-Verzeichnis, sofern vorhanden

Python-`pycache` wurde bewusst nicht archiviert, da es kein
Primärevidenzbestandteil ist.

## Methodische Entscheidung

Das maximale vorab definierte Profil `long4x` qualifizierte LP vollständig,
LN jedoch nicht. Es erfolgen keine identische Wiederholung, keine
Schwellenlockerung, keine Ausreißerentfernung und keine adaptive Verlängerung.
